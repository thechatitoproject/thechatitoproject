# The Chatito Project

A free GitHub Pages website for The Chatito Project.

## Files
- `index.html` — the complete website
- `assets/` — Carlos's photos

## Next step
Upload `index.html` and the entire `assets` folder to the GitHub repository, then enable GitHub Pages.
